/**
 * Interface de conversores de temperatura
 */
public interface Conversor {

    public double converte(double temperatura);
    
} 
