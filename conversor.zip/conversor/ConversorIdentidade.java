public class ConversorIdentidade implements Conversor {

    @Override
    public double converte(double temperatura) {
        return temperatura;
    }
    
}
